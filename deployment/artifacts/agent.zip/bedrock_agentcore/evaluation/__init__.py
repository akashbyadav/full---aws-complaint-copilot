"""AgentCore Evaluation: EvaluationClient, OnDemandEvaluationDatasetRunner, and Strands integration."""

from bedrock_agentcore._utils.config import WaitConfig
from bedrock_agentcore.evaluation.client import EvaluationClient, ReferenceInputs
from bedrock_agentcore.evaluation.custom_code_based_evaluators import (
    EvaluatorInput,
    EvaluatorOutput,
    ReferenceInput,
    custom_code_based_evaluator,
)
from bedrock_agentcore.evaluation.dataset_client import DatasetClient
from bedrock_agentcore.evaluation.runner.batch.batch_evaluation_models import (
    BatchEvaluationResult,
    BatchEvaluationRunConfig,
    BatchEvaluationSummary,
    BatchEvaluatorConfig,
    CloudWatchDataSourceConfig,
    CloudWatchOutputDataConfig,
    EvaluatorStatistics,
    EvaluatorSummary,
    FailedScenario,
    OnlineEvaluationDataSourceConfig,
)
from bedrock_agentcore.evaluation.runner.batch.batch_evaluation_runner import (
    BatchEvaluationRunner,
)
from bedrock_agentcore.evaluation.runner.dataset_providers import (
    DatasetManagementServiceProvider,
    DatasetProvider,
    FileDatasetProvider,
)
from bedrock_agentcore.evaluation.runner.dataset_types import (
    ActorProfile,
    Dataset,
    Input,
    PredefinedScenario,
    Scenario,
    SimulatedScenario,
    Turn,
)
from bedrock_agentcore.evaluation.runner.invoker_types import (
    AgentInvokerFn,
    AgentInvokerInput,
    AgentInvokerOutput,
)
from bedrock_agentcore.evaluation.runner.on_demand import (
    AgentSpanCollector,
    CloudWatchAgentSpanCollector,
    EvaluationResult,
    EvaluationRunConfig,
    EvaluatorConfig,
    EvaluatorResult,
    OnDemandEvaluationDatasetRunner,
    PredefinedScenarioExecutor,
    ScenarioExecutionResult,
    ScenarioExecutor,
    ScenarioResult,
    SimulatedScenarioExecutor,
    SimulationConfig,
)
from bedrock_agentcore.evaluation.span_to_adot_serializer import (
    convert_strands_to_adot,
)
from bedrock_agentcore.evaluation.spans import is_tool_span, tool_span_ids, trace_ids
from bedrock_agentcore.evaluation.utils.cloudwatch_span_helper import (
    fetch_spans_from_cloudwatch,
)

__all__ = [
    "WaitConfig",
    "ActorProfile",
    "AgentInvokerFn",
    "BatchEvaluationRunner",
    "BatchEvaluationResult",
    "BatchEvaluationRunConfig",
    "CloudWatchOutputDataConfig",
    "CloudWatchDataSourceConfig",
    "OnlineEvaluationDataSourceConfig",
    "BatchEvaluatorConfig",
    "BatchEvaluationSummary",
    "EvaluatorStatistics",
    "EvaluatorSummary",
    "FailedScenario",
    "AgentInvokerInput",
    "AgentInvokerOutput",
    "CloudWatchAgentSpanCollector",
    "Dataset",
    "DatasetClient",
    "DatasetProvider",
    "EvaluationClient",
    "EvaluationResult",
    "EvaluationRunConfig",
    "EvaluatorConfig",
    "EvaluatorInput",
    "EvaluatorOutput",
    "EvaluatorResult",
    "FileDatasetProvider",
    "DatasetManagementServiceProvider",
    "Input",
    "OnDemandEvaluationDatasetRunner",
    "ReferenceInputs",
    "Scenario",
    "ScenarioExecutionResult",
    "ScenarioExecutor",
    "ScenarioResult",
    "AgentSpanCollector",
    "SimulationConfig",
    "StrandsEvalsAgentCoreEvaluator",
    "Turn",
    "PredefinedScenario",
    "PredefinedScenarioExecutor",
    "ReferenceInput",
    "SimulatedScenario",
    "SimulatedScenarioExecutor",
    "custom_code_based_evaluator",
    "convert_strands_to_adot",
    "create_strands_evaluator",
    "fetch_spans_from_cloudwatch",
    "is_tool_span",
    "tool_span_ids",
    "trace_ids",
]

_STRANDS_EVALS_EXTRAS = {
    "StrandsEvalsAgentCoreEvaluator",
    "create_strands_evaluator",
}


def __getattr__(name: str):
    """Lazy import for optional strands-agents-evals dependencies."""
    if name in _STRANDS_EVALS_EXTRAS:
        try:
            from bedrock_agentcore.evaluation.integrations.strands_agents_evals.evaluator import (
                StrandsEvalsAgentCoreEvaluator,
                create_strands_evaluator,
            )
        except ImportError as e:
            raise ImportError(
                f"'{name}' requires the 'strands-agents-evals' extra. "
                "Install it with: pip install 'bedrock-agentcore[strands-agents-evals]'"
            ) from e

        _lazy = {
            "StrandsEvalsAgentCoreEvaluator": StrandsEvalsAgentCoreEvaluator,
            "create_strands_evaluator": create_strands_evaluator,
        }
        return _lazy[name]

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
